const DASHBOARD_CONFIG = {
    environments: [
        {
            id: "dev",
            name: "DEV",
            badge: "dev",
            regions: [{ id: "global", name: "Global" }],
            applications: [
                {
                    name: "Shares",
                    links: {
                        vault: "https://vault-dev.internal/ui/vault/secrets/shares",
                        azure: "https://portal.azure.com/#/resource/dev-shares-rg"
                    },
                    components: [
                        {
                            id: "D9Z", name: "D9Z - Order Management",
                            links: {
                                splunk: "https://splunk-dev.internal/app/shares_d9z",
                                appDynamics: "https://appdyn-dev.internal/shares/d9z",
                                grafana: "https://grafana-dev.internal/d/shares-d9z",
                                jenkins: "https://jenkins-dev.internal/job/shares-d9z"
                            }
                        },
                        {
                            id: "E47", name: "E47 - Trade Execution",
                            links: {
                                splunk: "https://splunk-dev.internal/app/shares_e47",
                                appDynamics: "https://appdyn-dev.internal/shares/e47",
                                grafana: "https://grafana-dev.internal/d/shares-e47",
                                jenkins: "https://jenkins-dev.internal/job/shares-e47"
                            }
                        },
                        {
                            id: "F12", name: "F12 - Market Data",
                            links: {
                                splunk: "https://splunk-dev.internal/app/shares_f12",
                                appDynamics: "https://appdyn-dev.internal/shares/f12",
                                grafana: "https://grafana-dev.internal/d/shares-f12",
                                jenkins: "https://jenkins-dev.internal/job/shares-f12"
                            }
                        }
                    ]
                },
                {
                    name: "Sales",
                    links: {
                        vault: "https://vault-dev.internal/ui/vault/secrets/sales",
                        azure: "https://portal.azure.com/#/resource/dev-sales-rg"
                    },
                    components: [
                        {
                            id: "D9Z", name: "D9Z - Client Portal",
                            links: {
                                splunk: "https://splunk-dev.internal/app/sales_d9z",
                                appDynamics: "https://appdyn-dev.internal/sales/d9z",
                                grafana: "https://grafana-dev.internal/d/sales-d9z",
                                jenkins: "https://jenkins-dev.internal/job/sales-d9z"
                            }
                        },
                        {
                            id: "E47", name: "E47 - CRM Integration",
                            links: {
                                splunk: "https://splunk-dev.internal/app/sales_e47",
                                appDynamics: "https://appdyn-dev.internal/sales/e47",
                                grafana: "https://grafana-dev.internal/d/sales-e47",
                                jenkins: "https://jenkins-dev.internal/job/sales-e47"
                            }
                        }
                    ]
                },
                {
                    name: "Services",
                    links: {
                        vault: "https://vault-dev.internal/ui/vault/secrets/services",
                        azure: "https://portal.azure.com/#/resource/dev-services-rg"
                    },
                    components: [
                        {
                            id: "D9Z", name: "D9Z - API Gateway",
                            links: {
                                splunk: "https://splunk-dev.internal/app/services_d9z",
                                appDynamics: "https://appdyn-dev.internal/services/d9z",
                                grafana: "https://grafana-dev.internal/d/services-d9z",
                                jenkins: "https://jenkins-dev.internal/job/services-d9z"
                            }
                        },
                        {
                            id: "E47", name: "E47 - Auth Service",
                            links: {
                                splunk: "https://splunk-dev.internal/app/services_e47",
                                appDynamics: "https://appdyn-dev.internal/services/e47",
                                grafana: "https://grafana-dev.internal/d/services-e47",
                                jenkins: "https://jenkins-dev.internal/job/services-e47"
                            }
                        },
                        {
                            id: "G83", name: "G83 - Notification Hub",
                            links: {
                                splunk: "https://splunk-dev.internal/app/services_g83",
                                appDynamics: "https://appdyn-dev.internal/services/g83",
                                grafana: "https://grafana-dev.internal/d/services-g83",
                                jenkins: "https://jenkins-dev.internal/job/services-g83"
                            }
                        }
                    ]
                }
            ]
        },
        {
            id: "te1",
            name: "TE1",
            badge: "te",
            regions: [{ id: "global", name: "Global" }],
            applications: [
                {
                    name: "Shares",
                    links: {
                        vault: "https://vault-te1.internal/ui/vault/secrets/shares",
                        azure: "https://portal.azure.com/#/resource/te1-shares-rg"
                    },
                    components: [
                        { id: "D9Z", name: "D9Z - Order Management", links: { splunk: "https://splunk-te1.internal/app/shares_d9z", appDynamics: "https://appdyn-te1.internal/shares/d9z", grafana: "https://grafana-te1.internal/d/shares-d9z", jenkins: "https://jenkins-te1.internal/job/shares-d9z" } },
                        { id: "E47", name: "E47 - Trade Execution", links: { splunk: "https://splunk-te1.internal/app/shares_e47", appDynamics: "https://appdyn-te1.internal/shares/e47", grafana: "https://grafana-te1.internal/d/shares-e47", jenkins: "https://jenkins-te1.internal/job/shares-e47" } },
                        { id: "F12", name: "F12 - Market Data", links: { splunk: "https://splunk-te1.internal/app/shares_f12", appDynamics: "https://appdyn-te1.internal/shares/f12", grafana: "https://grafana-te1.internal/d/shares-f12", jenkins: "https://jenkins-te1.internal/job/shares-f12" } }
                    ]
                },
                {
                    name: "Sales",
                    links: {
                        vault: "https://vault-te1.internal/ui/vault/secrets/sales",
                        azure: "https://portal.azure.com/#/resource/te1-sales-rg"
                    },
                    components: [
                        { id: "D9Z", name: "D9Z - Client Portal", links: { splunk: "https://splunk-te1.internal/app/sales_d9z", appDynamics: "https://appdyn-te1.internal/sales/d9z", grafana: "https://grafana-te1.internal/d/sales-d9z", jenkins: "https://jenkins-te1.internal/job/sales-d9z" } },
                        { id: "E47", name: "E47 - CRM Integration", links: { splunk: "https://splunk-te1.internal/app/sales_e47", appDynamics: "https://appdyn-te1.internal/sales/e47", grafana: "https://grafana-te1.internal/d/sales-e47", jenkins: "https://jenkins-te1.internal/job/sales-e47" } }
                    ]
                },
                {
                    name: "Services",
                    links: {
                        vault: "https://vault-te1.internal/ui/vault/secrets/services",
                        azure: "https://portal.azure.com/#/resource/te1-services-rg"
                    },
                    components: [
                        { id: "D9Z", name: "D9Z - API Gateway", links: { splunk: "https://splunk-te1.internal/app/services_d9z", appDynamics: "https://appdyn-te1.internal/services/d9z", grafana: "https://grafana-te1.internal/d/services-d9z", jenkins: "https://jenkins-te1.internal/job/services-d9z" } },
                        { id: "E47", name: "E47 - Auth Service", links: { splunk: "https://splunk-te1.internal/app/services_e47", appDynamics: "https://appdyn-te1.internal/services/e47", grafana: "https://grafana-te1.internal/d/services-e47", jenkins: "https://jenkins-te1.internal/job/services-e47" } },
                        { id: "G83", name: "G83 - Notification Hub", links: { splunk: "https://splunk-te1.internal/app/services_g83", appDynamics: "https://appdyn-te1.internal/services/g83", grafana: "https://grafana-te1.internal/d/services-g83", jenkins: "https://jenkins-te1.internal/job/services-g83" } }
                    ]
                }
            ]
        },
        {
            id: "te2",
            name: "TE2",
            badge: "te",
            regions: [
                { id: "ch", name: "CH (Switzerland)" },
                { id: "apac", name: "APAC" },
                { id: "emea", name: "EMEA" }
            ],
            applications: [
                {
                    name: "Shares",
                    links: {
                        vault: "https://vault-te2-{region}.internal/ui/vault/secrets/shares",
                        azure: "https://portal.azure.com/#/resource/te2-{region}-shares-rg"
                    },
                    components: [
                        { id: "D9Z", name: "D9Z - Order Management", links: { splunk: "https://splunk-te2-{region}.internal/app/shares_d9z", appDynamics: "https://appdyn-te2-{region}.internal/shares/d9z", grafana: "https://grafana-te2-{region}.internal/d/shares-d9z", jenkins: "https://jenkins-te2.internal/job/shares-d9z-{region}" } },
                        { id: "E47", name: "E47 - Trade Execution", links: { splunk: "https://splunk-te2-{region}.internal/app/shares_e47", appDynamics: "https://appdyn-te2-{region}.internal/shares/e47", grafana: "https://grafana-te2-{region}.internal/d/shares-e47", jenkins: "https://jenkins-te2.internal/job/shares-e47-{region}" } },
                        { id: "F12", name: "F12 - Market Data", links: { splunk: "https://splunk-te2-{region}.internal/app/shares_f12", appDynamics: "https://appdyn-te2-{region}.internal/shares/f12", grafana: "https://grafana-te2-{region}.internal/d/shares-f12", jenkins: "https://jenkins-te2.internal/job/shares-f12-{region}" } }
                    ]
                },
                {
                    name: "Sales",
                    links: {
                        vault: "https://vault-te2-{region}.internal/ui/vault/secrets/sales",
                        azure: "https://portal.azure.com/#/resource/te2-{region}-sales-rg"
                    },
                    components: [
                        { id: "D9Z", name: "D9Z - Client Portal", links: { splunk: "https://splunk-te2-{region}.internal/app/sales_d9z", appDynamics: "https://appdyn-te2-{region}.internal/sales/d9z", grafana: "https://grafana-te2-{region}.internal/d/sales-d9z", jenkins: "https://jenkins-te2.internal/job/sales-d9z-{region}" } },
                        { id: "E47", name: "E47 - CRM Integration", links: { splunk: "https://splunk-te2-{region}.internal/app/sales_e47", appDynamics: "https://appdyn-te2-{region}.internal/sales/e47", grafana: "https://grafana-te2-{region}.internal/d/sales-e47", jenkins: "https://jenkins-te2.internal/job/sales-e47-{region}" } }
                    ]
                },
                {
                    name: "Services",
                    links: {
                        vault: "https://vault-te2-{region}.internal/ui/vault/secrets/services",
                        azure: "https://portal.azure.com/#/resource/te2-{region}-services-rg"
                    },
                    components: [
                        { id: "D9Z", name: "D9Z - API Gateway", links: { splunk: "https://splunk-te2-{region}.internal/app/services_d9z", appDynamics: "https://appdyn-te2-{region}.internal/services/d9z", grafana: "https://grafana-te2-{region}.internal/d/services-d9z", jenkins: "https://jenkins-te2.internal/job/services-d9z-{region}" } },
                        { id: "E47", name: "E47 - Auth Service", links: { splunk: "https://splunk-te2-{region}.internal/app/services_e47", appDynamics: "https://appdyn-te2-{region}.internal/services/e47", grafana: "https://grafana-te2-{region}.internal/d/services-e47", jenkins: "https://jenkins-te2.internal/job/services-e47-{region}" } },
                        { id: "G83", name: "G83 - Notification Hub", links: { splunk: "https://splunk-te2-{region}.internal/app/services_g83", appDynamics: "https://appdyn-te2-{region}.internal/services/g83", grafana: "https://grafana-te2-{region}.internal/d/services-g83", jenkins: "https://jenkins-te2.internal/job/services-g83-{region}" } }
                    ]
                }
            ]
        },
        {
            id: "prod",
            name: "PROD",
            badge: "prod",
            regions: [
                { id: "ch", name: "CH (Switzerland)" },
                { id: "apac", name: "APAC" },
                { id: "emea", name: "EMEA" }
            ],
            applications: [
                {
                    name: "Shares",
                    links: {
                        vault: "https://vault-prod-{region}.internal/ui/vault/secrets/shares",
                        azure: "https://portal.azure.com/#/resource/prod-{region}-shares-rg"
                    },
                    components: [
                        { id: "D9Z", name: "D9Z - Order Management", links: { splunk: "https://splunk-prod-{region}.internal/app/shares_d9z", appDynamics: "https://appdyn-prod-{region}.internal/shares/d9z", grafana: "https://grafana-prod-{region}.internal/d/shares-d9z", jenkins: "https://jenkins-prod.internal/job/shares-d9z-{region}" } },
                        { id: "E47", name: "E47 - Trade Execution", links: { splunk: "https://splunk-prod-{region}.internal/app/shares_e47", appDynamics: "https://appdyn-prod-{region}.internal/shares/e47", grafana: "https://grafana-prod-{region}.internal/d/shares-e47", jenkins: "https://jenkins-prod.internal/job/shares-e47-{region}" } },
                        { id: "F12", name: "F12 - Market Data", links: { splunk: "https://splunk-prod-{region}.internal/app/shares_f12", appDynamics: "https://appdyn-prod-{region}.internal/shares/f12", grafana: "https://grafana-prod-{region}.internal/d/shares-f12", jenkins: "https://jenkins-prod.internal/job/shares-f12-{region}" } }
                    ]
                },
                {
                    name: "Sales",
                    links: {
                        vault: "https://vault-prod-{region}.internal/ui/vault/secrets/sales",
                        azure: "https://portal.azure.com/#/resource/prod-{region}-sales-rg"
                    },
                    components: [
                        { id: "D9Z", name: "D9Z - Client Portal", links: { splunk: "https://splunk-prod-{region}.internal/app/sales_d9z", appDynamics: "https://appdyn-prod-{region}.internal/sales/d9z", grafana: "https://grafana-prod-{region}.internal/d/sales-d9z", jenkins: "https://jenkins-prod.internal/job/sales-d9z-{region}" } },
                        { id: "E47", name: "E47 - CRM Integration", links: { splunk: "https://splunk-prod-{region}.internal/app/sales_e47", appDynamics: "https://appdyn-prod-{region}.internal/sales/e47", grafana: "https://grafana-prod-{region}.internal/d/sales-e47", jenkins: "https://jenkins-prod.internal/job/sales-e47-{region}" } }
                    ]
                },
                {
                    name: "Services",
                    links: {
                        vault: "https://vault-prod-{region}.internal/ui/vault/secrets/services",
                        azure: "https://portal.azure.com/#/resource/prod-{region}-services-rg"
                    },
                    components: [
                        { id: "D9Z", name: "D9Z - API Gateway", links: { splunk: "https://splunk-prod-{region}.internal/app/services_d9z", appDynamics: "https://appdyn-prod-{region}.internal/services/d9z", grafana: "https://grafana-prod-{region}.internal/d/services-d9z", jenkins: "https://jenkins-prod.internal/job/services-d9z-{region}" } },
                        { id: "E47", name: "E47 - Auth Service", links: { splunk: "https://splunk-prod-{region}.internal/app/services_e47", appDynamics: "https://appdyn-prod-{region}.internal/services/e47", grafana: "https://grafana-prod-{region}.internal/d/services-e47", jenkins: "https://jenkins-prod.internal/job/services-e47-{region}" } },
                        { id: "G83", name: "G83 - Notification Hub", links: { splunk: "https://splunk-prod-{region}.internal/app/services_g83", appDynamics: "https://appdyn-prod-{region}.internal/services/g83", grafana: "https://grafana-prod-{region}.internal/d/services-g83", jenkins: "https://jenkins-prod.internal/job/services-g83-{region}" } }
                    ]
                }
            ]
        }
    ],
    toolIcons: {
        splunk: { label: "Splunk", color: "#65A637", icon: "📊", tier: "component" },
        appDynamics: { label: "AppDynamics", color: "#6B48C9", icon: "📈", tier: "component" },
        azure: { label: "Azure", color: "#0078D4", icon: "☁️", tier: "application" },
        vault: { label: "HashiCorp Vault", color: "#000000", icon: "🔐", tier: "application" },
        grafana: { label: "Grafana", color: "#F46800", icon: "📉", tier: "component" },
        jenkins: { label: "Jenkins", color: "#D33833", icon: "⚙️", tier: "component" }
    }
};
