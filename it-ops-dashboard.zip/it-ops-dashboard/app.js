/* ============================================
   IT Operations Dashboard - Application Logic
   Two-Tier Link Architecture
   ============================================ */

// State
const state = {
    activeEnvs: new Set(),
    activeRegions: new Set(),
    activeApps: new Set(),
    activeTools: new Set(),
    searchTerm: '',
    expandedEnvs: new Set(),
    expandedApps: new Set(),
    activeRegionTabs: {}
};

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', () => {
    initTimestamp();
    initFilters();
    renderDashboard();
    updateStats();
    bindSearch();
});

function initTimestamp() {
    const el = document.getElementById('last-updated');
    if (el) el.textContent = 'Last updated: ' + new Date().toLocaleDateString('en-GB', {
        day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
}

// ===== FILTER INITIALIZATION =====
function initFilters() {
    const envContainer = document.getElementById('env-filters');
    const regionContainer = document.getElementById('region-filters');
    const appContainer = document.getElementById('app-filters');
    const toolContainer = document.getElementById('tool-filters');

    // Environment chips
    DASHBOARD_CONFIG.environments.forEach(env => {
        envContainer.appendChild(createChip(env.name, 'env', env.id));
    });

    // Region chips (unique)
    const regions = new Set();
    DASHBOARD_CONFIG.environments.forEach(env =>
        env.regions.forEach(r => regions.add(JSON.stringify(r)))
    );
    [...regions].map(r => JSON.parse(r)).forEach(r => {
        regionContainer.appendChild(createChip(r.name, 'region', r.id));
    });

    // Application chips (unique)
    const apps = new Set();
    DASHBOARD_CONFIG.environments.forEach(env =>
        env.applications.forEach(a => apps.add(a.name))
    );
    [...apps].forEach(name => {
        appContainer.appendChild(createChip(name, 'app', name));
    });

    // Tool chips
    Object.entries(DASHBOARD_CONFIG.toolIcons).forEach(([key, tool]) => {
        const tierLabel = tool.tier === 'application' ? ' (App)' : '';
        toolContainer.appendChild(createChip(tool.icon + ' ' + tool.label + tierLabel, 'tool', key));
    });
}

function createChip(label, type, value) {
    const chip = document.createElement('button');
    chip.className = 'chip';
    chip.textContent = label;
    chip.dataset.type = type;
    chip.dataset.value = value;
    chip.onclick = () => toggleFilter(type, value, chip);
    return chip;
}

function toggleFilter(type, value, chipEl) {
    const setMap = {
        env: state.activeEnvs,
        region: state.activeRegions,
        app: state.activeApps,
        tool: state.activeTools
    };
    const set = setMap[type];
    if (set.has(value)) {
        set.delete(value);
        chipEl.classList.remove('active');
    } else {
        set.add(value);
        chipEl.classList.add('active');
    }
    renderDashboard();
    updateStats();
}

function clearFilters() {
    state.activeEnvs.clear();
    state.activeRegions.clear();
    state.activeApps.clear();
    state.activeTools.clear();
    state.searchTerm = '';
    document.getElementById('global-search').value = '';
    document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
    renderDashboard();
    updateStats();
}

function bindSearch() {
    const input = document.getElementById('global-search');
    let debounce;
    input.addEventListener('input', (e) => {
        clearTimeout(debounce);
        debounce = setTimeout(() => {
            state.searchTerm = e.target.value.toLowerCase().trim();
            renderDashboard();
            updateStats();
        }, 200);
    });
}

// ===== EXPAND / COLLAPSE =====
function expandAll() {
    DASHBOARD_CONFIG.environments.forEach(env => {
        state.expandedEnvs.add(env.id);
        autoExpandAppsForEnv(env);
    });
    renderDashboard();
}

function collapseAll() {
    state.expandedEnvs.clear();
    state.expandedApps.clear();
    renderDashboard();
}

function toggleEnv(envId) {
    if (state.expandedEnvs.has(envId)) {
        // Collapse this env
        state.expandedEnvs.delete(envId);
        // Remove all app keys for this env
        clearAppsForEnv(envId);
    } else {
        // Accordion: close all other envs first
        state.expandedEnvs.forEach(otherEnvId => {
            clearAppsForEnv(otherEnvId);
        });
        state.expandedEnvs.clear();

        // Open this env and auto-expand all its apps
        state.expandedEnvs.add(envId);
        const env = DASHBOARD_CONFIG.environments.find(e => e.id === envId);
        if (env) autoExpandAppsForEnv(env);
    }
    renderDashboard();
}

// Auto-expand all applications for a given environment
function autoExpandAppsForEnv(env) {
    env.applications.forEach(app => {
        env.regions.forEach(r => {
            state.expandedApps.add(`${env.id}-${r.id}-${app.name}`);
        });
    });
}

// Clear all expanded app keys belonging to a specific environment
function clearAppsForEnv(envId) {
    state.expandedApps.forEach(key => {
        if (key.startsWith(envId + '-')) {
            state.expandedApps.delete(key);
        }
    });
}

function toggleApp(key) {
    if (state.expandedApps.has(key)) state.expandedApps.delete(key);
    else state.expandedApps.add(key);
    renderDashboard();
}

function switchRegionTab(envId, regionId) {
    state.activeRegionTabs[envId] = regionId;
    // Auto-expand apps for the new region tab
    const env = DASHBOARD_CONFIG.environments.find(e => e.id === envId);
    if (env) {
        env.applications.forEach(app => {
            state.expandedApps.add(`${envId}-${regionId}-${app.name}`);
        });
    }
    renderDashboard();
}

// ===== LINK HELPERS =====
function resolveUrl(url, regionId) {
    return url.replace(/{region}/g, regionId);
}

function renderToolLink(toolKey, url, regionId, extraClass) {
    const tool = DASHBOARD_CONFIG.toolIcons[toolKey];
    if (!tool) return '';
    const resolvedUrl = resolveUrl(url, regionId);
    const cls = extraClass ? `tool-link ${extraClass}` : 'tool-link';
    return `<a href="${resolvedUrl}" target="_blank" rel="noopener" class="${cls}" data-tool="${toolKey}" title="${tool.label}">
    <span class="tool-emoji">${tool.icon}</span> ${tool.label}
  </a>`;
}

function getFilteredLinks(links, tier) {
    const entries = Object.entries(links || {});
    // If tool filter is active, only show matching tools
    if (state.activeTools.size) {
        return entries.filter(([key]) => state.activeTools.has(key));
    }
    // Otherwise show links appropriate for this tier (or all if no tier metadata)
    if (tier) {
        return entries.filter(([key]) => {
            const toolMeta = DASHBOARD_CONFIG.toolIcons[key];
            return toolMeta && toolMeta.tier === tier;
        });
    }
    return entries;
}

// ===== FILTERING LOGIC =====
function matchesSearch(env, app, component) {
    if (!state.searchTerm) return true;
    const haystack = [
        env.name, app.name,
        component ? component.id : '',
        component ? component.name : ''
    ].join(' ').toLowerCase();
    return haystack.includes(state.searchTerm);
}

function appHasVisibleContent(env, region, app) {
    if (state.activeApps.size && !state.activeApps.has(app.name)) return false;
    if (state.activeRegions.size && !state.activeRegions.has(region.id)) return false;

    // Check app-level links
    const appLinks = getFilteredLinks(app.links, 'application');
    if (appLinks.length > 0 && matchesSearch(env, app, null)) return true;

    // Check component-level
    for (const comp of app.components) {
        const compLinks = getFilteredLinks(comp.links, 'component');
        if (compLinks.length > 0 && matchesSearch(env, app, comp)) return true;
    }

    return false;
}

// ===== RENDERING =====
function renderDashboard() {
    const container = document.getElementById('dashboard-content');
    container.innerHTML = '';
    let hasResults = false;

    DASHBOARD_CONFIG.environments.forEach(env => {
        if (state.activeEnvs.size && !state.activeEnvs.has(env.id)) return;

        // Check if any app has visible content in any region
        let envHasContent = false;
        env.regions.forEach(region => {
            env.applications.forEach(app => {
                if (appHasVisibleContent(env, region, app)) envHasContent = true;
            });
        });

        if (!envHasContent) return;
        hasResults = true;

        const section = document.createElement('div');
        section.className = 'env-section';
        section.id = `env-${env.id}`;

        const isExpanded = state.expandedEnvs.has(env.id);

        // ---- Environment Header ----
        const header = document.createElement('div');
        header.className = 'env-header';
        header.dataset.badge = env.badge;
        header.onclick = () => toggleEnv(env.id);

        const regionBadgesHtml = env.regions.map(r =>
            `<span class="region-pill">${r.name}</span>`
        ).join('');

        header.innerHTML = `
      <span class="env-badge ${env.badge}">${env.name}</span>
      <span class="env-title">${env.name} Environment</span>
      <div class="env-region-badges">${regionBadgesHtml}</div>
      <span class="toggle-icon ${isExpanded ? 'expanded' : ''}">▼</span>
    `;
        section.appendChild(header);

        // ---- Environment Body ----
        const body = document.createElement('div');
        body.className = `env-body ${isExpanded ? '' : 'collapsed'}`;

        if (isExpanded) {
            // Region tabs
            const filteredRegions = env.regions.filter(r =>
                !state.activeRegions.size || state.activeRegions.has(r.id)
            );
            const activeTab = state.activeRegionTabs[env.id]
                || (filteredRegions[0] ? filteredRegions[0].id : env.regions[0].id);

            if (filteredRegions.length > 1) {
                const tabs = document.createElement('div');
                tabs.className = 'region-tabs';
                filteredRegions.forEach(r => {
                    const tab = document.createElement('div');
                    tab.className = `region-tab ${r.id === activeTab ? 'active' : ''}`;
                    tab.textContent = r.name;
                    tab.onclick = (e) => { e.stopPropagation(); switchRegionTab(env.id, r.id); };
                    tabs.appendChild(tab);
                });
                body.appendChild(tabs);
            }

            const currentRegion = filteredRegions.find(r => r.id === activeTab)
                || filteredRegions[0] || env.regions[0];

            // ---- Applications ----
            env.applications.forEach(app => {
                if (state.activeApps.size && !state.activeApps.has(app.name)) return;
                if (!appHasVisibleContent(env, currentRegion, app)) return;

                const appKey = `${env.id}-${currentRegion.id}-${app.name}`;
                const appExpanded = state.expandedApps.has(appKey);
                const appIconClass = app.name.toLowerCase().replace(/\s/g, '');

                const appSection = document.createElement('div');
                appSection.className = 'app-section';

                // App header
                const appHeader = document.createElement('div');
                appHeader.className = 'app-header';
                appHeader.onclick = () => toggleApp(appKey);

                const compCount = app.components.filter(comp =>
                    matchesSearch(env, app, comp) &&
                    getFilteredLinks(comp.links, 'component').length > 0
                ).length;

                appHeader.innerHTML = `
          <div class="app-icon ${appIconClass}">${app.name.charAt(0)}</div>
          <span class="app-name">${app.name}</span>
          <span class="app-count">${compCount} components</span>
          <span class="app-toggle ${appExpanded ? 'expanded' : ''}">▼</span>
        `;
                appSection.appendChild(appHeader);

                // ---- App-level links bar ----
                const appLevelLinks = getFilteredLinks(app.links, 'application');
                if (appLevelLinks.length > 0 && matchesSearch(env, app, null)) {
                    const appLinksBar = document.createElement('div');
                    appLinksBar.className = 'app-level-links';

                    const label = document.createElement('span');
                    label.className = 'app-links-label';
                    label.textContent = 'Application Resources';
                    appLinksBar.appendChild(label);

                    const linksWrap = document.createElement('div');
                    linksWrap.className = 'app-links-wrap';
                    appLevelLinks.forEach(([toolKey, url]) => {
                        linksWrap.innerHTML += renderToolLink(toolKey, url, currentRegion.id, 'app-tier');
                    });
                    appLinksBar.appendChild(linksWrap);
                    appSection.appendChild(appLinksBar);
                }

                // ---- Component table ----
                const compTable = document.createElement('div');
                compTable.className = `component-table ${appExpanded ? '' : 'collapsed'}`;

                if (appExpanded) {
                    const matchedComponents = app.components.filter(comp =>
                        matchesSearch(env, app, comp) &&
                        getFilteredLinks(comp.links, 'component').length > 0
                    );

                    if (matchedComponents.length > 0) {
                        // Table header
                        const tableHeader = document.createElement('div');
                        tableHeader.className = 'comp-table-header';
                        tableHeader.innerHTML = `
              <div class="comp-th comp-th-id">Component</div>
              <div class="comp-th comp-th-links">Monitoring & CI/CD Links</div>
            `;
                        compTable.appendChild(tableHeader);

                        matchedComponents.forEach(comp => {
                            const row = document.createElement('div');
                            row.className = 'comp-row';

                            const compLinks = getFilteredLinks(comp.links, 'component');
                            const linksHtml = compLinks.map(([toolKey, url]) =>
                                renderToolLink(toolKey, url, currentRegion.id, '')
                            ).join('');

                            row.innerHTML = `
                <div class="comp-id"><code>${comp.id}</code> ${comp.name.replace(comp.id + ' - ', '')}</div>
                <div class="comp-links">${linksHtml}</div>
              `;
                            compTable.appendChild(row);
                        });
                    }
                }

                appSection.appendChild(compTable);
                body.appendChild(appSection);
            });
        }

        section.appendChild(body);
        container.appendChild(section);
    });

    if (!hasResults) {
        container.innerHTML = `
      <div class="no-results">
        <div class="no-results-icon">🔍</div>
        <h3>No matching results</h3>
        <p>Try adjusting your filters or search term</p>
      </div>
    `;
    }
}

// ===== STATS =====
function updateStats() {
    let envCount = 0, appNames = new Set(), compCount = 0, linkCount = 0;

    DASHBOARD_CONFIG.environments.forEach(env => {
        if (state.activeEnvs.size && !state.activeEnvs.has(env.id)) return;
        envCount++;

        env.applications.forEach(app => {
            if (state.activeApps.size && !state.activeApps.has(app.name)) return;
            appNames.add(app.name);

            env.regions.forEach(region => {
                if (state.activeRegions.size && !state.activeRegions.has(region.id)) return;

                // App-level links
                const appLinks = getFilteredLinks(app.links, 'application');
                if (appLinks.length > 0 && matchesSearch(env, app, null)) {
                    linkCount += appLinks.length;
                }

                // Component-level
                app.components.forEach(comp => {
                    const compLinks = getFilteredLinks(comp.links, 'component');
                    if (compLinks.length > 0 && matchesSearch(env, app, comp)) {
                        compCount++;
                        linkCount += compLinks.length;
                    }
                });
            });
        });
    });

    animateCounter('stat-envs', envCount);
    animateCounter('stat-apps', appNames.size);
    animateCounter('stat-components', compCount);
    animateCounter('stat-links', linkCount);
}

function animateCounter(id, target) {
    const el = document.getElementById(id);
    const current = parseInt(el.textContent) || 0;
    if (current === target) return;
    const steps = 15;
    const increment = (target - current) / steps;
    let step = 0;
    const timer = setInterval(() => {
        step++;
        el.textContent = Math.round(current + increment * step);
        if (step >= steps) {
            el.textContent = target;
            clearInterval(timer);
        }
    }, 20);
}
